class Merchant {
  final int merchantId;
  final String merchantName;
  final String merchantAdd;
  final int merchantNumber;
  final String merchantWebsite;
  final String bussinessType;


  Merchant({
    this.merchantId,
    this.merchantName,
    this.merchantAdd,
    this.merchantNumber,
    this.merchantWebsite,
    this.bussinessType
  });
}